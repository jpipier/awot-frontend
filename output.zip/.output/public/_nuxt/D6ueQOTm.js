import{u as R,p as z,q as K}from"./GilpQ00N.js";import{_ as Q}from"./DNG3KFMV.js";import{I as W,r as A,i as X,J as Y,K as Z,e as ee,c as s,b as y,a as t,M as F,t as r,F as p,N as T,O as E,H as P,A as te,o,w as G,d as se}from"./Cl0o2Htt.js";import"./DlAUqK2U.js";const oe={class:"container mx-auto py-10 template-categories pr-5 pl-5 md:pr-0 md:pl-0"},ae={class:"text-6xl text-center mb-6 font-custom pb-10"},le={key:0,class:"mb-8 pb-10 w-full md:w-1/2 mx-auto"},re={class:"flex flex-wrap align-center gap-3 justify-center"},ne={key:1,class:"grid grid-cols-1 sm:grid-cols-3 gap-8 auto-rows-auto"},ce={key:0,class:"flex flex-col sm:flex-row gap-6 items-center"},ie={class:"w-full sm:w-2/3 max-h-full md:max-h-[600px] overflow-hidden"},ue=["src","alt"],de={class:"w-full sm:w-1/3 flex flex-col jusctify-center"},me={class:"text-xs uppercase italic text-gray-500 mb-1"},ge={class:"text-xl font-semibold mb-2"},_e=["innerHTML"],pe={key:1},he={key:0,class:"aspect-[3/4] overflow-hidden"},fe=["src","alt"],xe={class:"mt-2 text-xs uppercase italic text-gray-500"},ye={class:"text-sm font-medium leading-snug"},be={key:2},Ie={__name:"[slug]",async setup(ve){let h,I;const J=te(),b=W(),L=b.params.slug,v=A(10),w=A([]),k=A(null),N=X(()=>{var i,f,u,d,e,m,g,_;const a=((u=(f=(i=n.value)==null?void 0:i.category)==null?void 0:f.children)==null?void 0:u.nodes)||[],l=((_=(g=(m=(e=(d=n.value)==null?void 0:d.category)==null?void 0:e.parent)==null?void 0:m.node)==null?void 0:g.children)==null?void 0:_.nodes)||[];return(a.length?a:l).filter(x=>x.count>0)}),{data:n,error:we}=([h,I]=Y(async()=>R(`category-${L}`,async()=>(await $fetch(J.public.wordpressUrl,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:`
        query GetCategory($slug: ID!, $limit: Int!) {
          category(id: $slug, idType: SLUG) {
            name
            parent {
              node {
                id
                slug
                name
                children(first: 100) {
                  nodes {
                    name
                    slug
                    count
                  }
                }
              }
            }
            children(first: 100) {
              nodes {
                name
                slug
                count
              }
            }
            posts(first: $limit) {
              nodes {
                title
                slug
                featuredImage {
                  node {
                    sourceUrl
                    altText
                  }
                }
                excerpt
                content
                optionsArticles {
                  champsLibrePageAccueil
                  imagePortait {
                    node {
                      sourceUrl
                      altText
                    }
                  }
                  imagePaysage {
                    node {
                      sourceUrl
                      altText
                    }
                  }
                }
              }
            }
          }
          allCategories: categories(first: 100) {
            nodes {
              name
              slug
            }
          }
        }
      `,variables:{slug:L,limit:v.value}})})).data,{watch:[v]})),h=await h,I(),h);return Z(()=>{var a,l,c;(c=(l=(a=n.value)==null?void 0:a.category)==null?void 0:l.posts)!=null&&c.nodes&&(w.value=n.value.category.posts.nodes)}),ee(()=>{const a=new IntersectionObserver(l=>{l[0].isIntersecting&&(v.value+=10)});k.value&&a.observe(k.value)}),(a,l)=>{var u,d;const c=z,i=Q,f=K;return o(),s(T,null,[y(c),t("div",oe,[t("h1",ae,r((d=(u=p(n))==null?void 0:u.category)==null?void 0:d.name),1),p(N).length?(o(),s("div",le,[t("ul",re,[(o(!0),s(T,null,E(p(N),e=>(o(),s("li",{key:e.slug,class:"mb-3"},[y(i,{to:"/categories/"+e.slug,class:P(["p-2 border border-black border-solid hover:text-white hover:bg-black duration-300",e.slug===p(b).params.slug?"bg-black text-white":""])},{default:G(()=>[se(r(e.name),1)]),_:2},1032,["to","class"])]))),128)),t("li",null,[t("a",{href:"/categories/voyages",class:P(["p-2 border border-black border-solid hover:text-white-600",p(b).params.slug==="voyages"?"bg-black text-white":""])},"Tous les voyages ",2)])])])):F("",!0),w.value.length?(o(),s("ul",ne,[(o(!0),s(T,null,E(w.value,(e,m)=>(o(),s("li",{key:e.slug,class:P([(m+1)%4===0?"sm:col-span-3 max-h-full md:max-h-[600px]":"sm:col-span-1","w-full"])},[y(i,{to:"/articles/"+e.slug,class:"block group"},{default:G(()=>{var g,_,x,U,C,$,j,H,M,O,S,V,q,B,D;return[(m+1)%4===0?(o(),s("div",ce,[t("div",ie,[t("img",{src:((x=(_=(g=e.optionsArticles)==null?void 0:g.imagePaysage)==null?void 0:_.node)==null?void 0:x.sourceUrl)||((C=(U=e.featuredImage)==null?void 0:U.node)==null?void 0:C.sourceUrl),alt:((j=($=e.featuredImage)==null?void 0:$.node)==null?void 0:j.altText)||e.title,class:"w-full object-cover aspect-[3/4] transition-transform duration-300 group-hover:scale-110 rounded-lg max-h-full md:max-h-[600px]"},null,8,ue)]),t("div",de,[t("div",me,r((H=e.optionsArticles)==null?void 0:H.champsLibrePageAccueil),1),t("h2",ge,r(e.title),1),t("div",{class:"text-sm text-gray-700 mb-4 pt-2 pb-2",innerHTML:e.excerpt},null,8,_e),l[0]||(l[0]=t("div",null,[t("span",{class:"inline-block bg-black text-white text-xs px-4 py-2 rounded hover:bg-gray-800 transition"},"Lire l’article")],-1))])])):(o(),s("div",pe,[(O=(M=e.featuredImage)==null?void 0:M.node)!=null&&O.sourceUrl?(o(),s("div",he,[t("img",{src:(V=(S=e.optionsArticles)==null?void 0:S.imagePaysage)==null?void 0:V.node.sourceUrl,alt:((B=(q=e.optionsArticles)==null?void 0:q.imagePaysage)==null?void 0:B.node.altText)||e.title,class:"w-full object-cover aspect-[3/4] transition-transform duration-300 group-hover:scale-110 rounded-lg h-full"},null,8,fe)])):F("",!0),t("div",xe,r((D=e.optionsArticles)==null?void 0:D.champsLibrePageAccueil),1),t("h2",ye,r(e.title),1)]))]}),_:2},1032,["to"])],2))),128))])):(o(),s("p",be,"Aucun article pour cette catégorie.")),t("div",{ref_key:"sentinel",ref:k,class:"h-10"},null,512)]),y(f)],64)}}};export{Ie as default};
